<template>
  <div id="app">
    <el-input type="text" placeholder="请输入身份证" v-model="cardNo">
    </el-input>

    <el-row style="margin-top: 30px">
      <el-button type="primary" @click="doLogin" :loading="loading"
        >获取成绩</el-button
      >
      <el-button type="danger" @click="deleteThat" :loading="loading"
        >删除记录</el-button
      >
    </el-row>

    <el-row :gutter="20">
      <el-col :span="12" :key="item" v-for="item in historyList" >
        <el-tag style="margin-top:10px" @click="setMyItem(item)">
          {{ item }}
        </el-tag></el-col
      >
    </el-row>

    <el-table :data="result" style="width: 100%">
      <el-table-column prop="subjectName" label="科目名称"> </el-table-column>
      <el-table-column prop="outlineTime" label="大纲学时"> </el-table-column>
      <el-table-column prop="studyTime" label="培训学时"> </el-table-column>
      <el-table-column prop="gatherTime" label="有效学时"> </el-table-column>
      <el-table-column prop="mileage" label="培训公里数"> </el-table-column>
      <el-table-column prop="examDate" label="上报时间" :formatter="formate">
      </el-table-column>
      <el-table-column prop="approveDate" label="审核时间" :formatter="formate">
      </el-table-column>
      <el-table-column prop="leastStudyTime" label="最后学习时间">
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
import axios from "axios";
export default {
  name: "App",
  data() {
    return {
      cardNo: "",
      loading: false,
      result: [],
      historyList: [],
      test: [],
    };
  },
  created() {
    var store = localStorage.getItem("list");
    if (store) {
      var a = JSON.parse(store);
      if (Array.isArray(a)) {
        this.historyList = JSON.parse(JSON.stringify(a));
      } else {
        this.historyList = [];
      }
    } else {
      this.historyList = [];
    }

    console.log(this.historyList);
  },
  methods: {
    setMyItem(item) {
      console.log(1231231233333)
      this.cardNo = item;
    },
    formate(row, column, cellValue, index) {
      console.log(row, column, cellValue, index);
      return new Date(cellValue).toLocaleString();
    },
    deleteThat() {
      if (!this.cardNo) {
        alert("身份证号码不能为空");
        this.loading = false;
        return;
      }
      var list = this.historyList.filter((item) => item !== this.cardNo);
      localStorage.setItem("list", JSON.stringify(list));
      this.historyList = list;
      alert("删除成功");
      this.cardNo = "";
      this.result = [];
      this.loading = false;
    },

    doLogin() {
      this.loading = true;
      if (!this.cardNo) {
        alert("身份证号码不能为空");
        return;
      }

      axios
        .post("/ycjx/login", {
          cardNo: this.cardNo,
        })
        .then((response) => {
          console.log("response.data", response.data);
          if (response.data.code == 0) {
            this.loading = false;
            this.result = response.data.data;
            this.historyList.push(this.cardNo);
            var newArr = this.historyList.filter(
              (item, index) => this.historyList.indexOf(item) === index
            );
            localStorage.setItem("list", JSON.stringify(newArr));
            this.historyList = newArr;
          } else {
            alert(response.data.msg || "出错了");
            this.loading = false;
          }
        })
        .catch((error) => {
          this.loading = false;
          alert("出错了");
          console.log(error);
        });
    },
  },
};
</script>

<style>
#app {
}
</style>
